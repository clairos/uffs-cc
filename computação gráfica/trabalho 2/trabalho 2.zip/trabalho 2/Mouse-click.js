// aumenta o tamanho do cubo ao clicar na tela
window.addEventListener('click', () => {
    cube.scale.x += 0.1;
    cube.scale.y += 0.1;
    cube.scale.z += 0.1;
});
